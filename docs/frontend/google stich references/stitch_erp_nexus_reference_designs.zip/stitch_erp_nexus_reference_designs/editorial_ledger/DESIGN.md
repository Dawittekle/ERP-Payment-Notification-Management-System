---
name: Editorial Ledger
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#45464c'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#76777d'
  outline-variant: '#c6c6cd'
  surface-tint: '#575e70'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#141b2b'
  on-primary-container: '#7d8497'
  inverse-primary: '#c0c6db'
  secondary: '#712ae2'
  on-secondary: '#ffffff'
  secondary-container: '#8a4cfc'
  on-secondary-container: '#fffbff'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#001f26'
  on-tertiary-container: '#0090a9'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dce2f7'
  primary-fixed-dim: '#c0c6db'
  on-primary-fixed: '#141b2b'
  on-primary-fixed-variant: '#404758'
  secondary-fixed: '#eaddff'
  secondary-fixed-dim: '#d2bbff'
  on-secondary-fixed: '#25005a'
  on-secondary-fixed-variant: '#5a00c6'
  tertiary-fixed: '#acedff'
  tertiary-fixed-dim: '#4cd7f6'
  on-tertiary-fixed: '#001f26'
  on-tertiary-fixed-variant: '#004e5c'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  display-lg:
    fontFamily: Geist
    fontSize: 48px
    fontWeight: '600'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Geist
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Geist
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-md:
    fontFamily: Geist
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
  body-lg:
    fontFamily: Geist
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Geist
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  data-mono:
    fontFamily: Geist Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: -0.01em
  label-caps:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  caption:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  gutter: 24px
  margin-desktop: 40px
  margin-mobile: 16px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 32px
---

## Brand & Style
The design system is built on the philosophy of "Editorial Enterprise"—treating complex financial data with the clarity and hierarchy of a high-end publication. It serves the Ethiopian financial sector by balancing authoritative precision with a modern, Swiss-influenced aesthetic.

The visual direction follows a **Corporate / Modern** path with heavy influences from **Minimalism**. It prioritizes a data-rich calm, utilizing heavy whitespace and structured asymmetry to prevent cognitive overload. The "Transaction Signal" motif is the central visual metaphor: a singular, high-contrast accent used to draw immediate attention to critical financial movements or status changes amidst a sea of monochromatic stability.

## Colors
The palette is divided into two distinct operating modes: **Editorial Ledger** (Light) and **Operations Night** (Dark).

In Light Mode, the `Canvas` (#F8FAFC) provides a soft, paper-like background that reduces eye strain, while `Primary` (#111827) serves as the dominant ink for typography and structural borders. `Brand` (#7C3AED) is reserved for primary actions, and `Signal` (#06B6D4) is used exclusively for highlighting active transactions and data points.

Dark Mode shifts to a deep navy `Canvas` (#0B1020) to maintain professional depth. Across both modes, color is used sparingly as a functional tool rather than decoration. Status indicators (Success, Warning, Error) should be desaturated to fit the professional tone, only reaching full saturation when an immediate "Signal" is required.

## Typography
Typography is the primary driver of hierarchy. **Geist** is used for all UI elements, headings, and instructional text to maintain a clean, modernist feel. **Geist Mono** is strictly reserved for financial figures, transaction IDs, and tabular data to ensure perfect character alignment and a "technical ledger" aesthetic.

Large display headings should use tighter letter spacing and semi-bold weights to mimic editorial titles. For mobile, headline sizes are aggressively scaled down to preserve the "data-rich" density without horizontal scrolling. Use `label-caps` for table headers and small categorizations to create clear visual separation from record data.

## Layout & Spacing
This design system utilizes a **Fixed Grid** on desktop (1440px max-width) and a **Fluid Grid** for tablet and mobile. The grid follows a 12-column Swiss layout with generous 24px gutters.

Asymmetry is used intentionally: sidebars are wide and "heavy" (e.g., 280px), while main content areas use offset columns to create focus zones. Spacing is strictly based on a 4px baseline grid. On mobile, the 12-column grid collapses to 4 columns, and the desktop `margin-desktop` of 40px reduces to `margin-mobile` 16px to maximize data density. Content should be grouped into "modules" with consistent `stack-lg` (32px) vertical spacing between sections.

## Elevation & Depth
Depth is communicated through **Tonal Layers** and **Low-contrast outlines**. This system avoids heavy shadows to maintain its "flat-ledger" editorial feel.

1.  **Level 0 (Canvas):** The base background layer (#F8FAFC).
2.  **Level 1 (Surface):** White cards (#FFFFFF) use a 1px solid border (#E2E8F0) rather than a shadow. This creates a "printed" look.
3.  **Level 2 (Popovers/Modals):** Elements that sit above the UI use a very soft, highly diffused ambient shadow (8% opacity, 16px blur) combined with a 1px border to ensure clarity against white surfaces.

Interactive elements (buttons, inputs) do not "lift" on hover; instead, they shift in fill color or border intensity, reinforcing the tactile, flat nature of the interface.

## Shapes
The shape language is structured and professional. A base radius of **6px** is applied to standard UI components like inputs, buttons, and small cards to provide a "Soft" but disciplined feel.

Larger container elements like main dashboard modules or modals scale up to **20px** radius to create a distinct visual frame. **Pills are restricted**: they are only used for "Status Chips" (e.g., Pending, Completed) to distinguish them from interactive buttons. This prevents the UI from appearing too casual or "bubbly."

## Components
-   **Buttons:** Rectangular with a 6px radius. Primary buttons use the `Primary` color (#111827). "Transaction Signal" buttons use the `Brand` color (#7C3AED).
-   **Input Fields:** Ghost-style with a 1px border (#E2E8F0) and Geist Mono for any numerical entry. Focus state uses a 1px `Brand` border.
-   **Chips:** Pill-shaped only. Backgrounds are highly desaturated (5-10% opacity) versions of the status color, with high-contrast text.
-   **Data Tables:** The core of the ERP. No vertical borders; only horizontal 1px lines. Every second row uses a subtle #F8FAFC tint for readability. Headers use `label-caps`.
-   **Cards:** 1px solid border, 20px corner radius. No shadow. Used to group related financial metrics.
-   **Transaction Signal:** A vertical 4px bar placed on the left edge of a list item or card to denote the "Active" or "Unreconciled" status of a specific record.